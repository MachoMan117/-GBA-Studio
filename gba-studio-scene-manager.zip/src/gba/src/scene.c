#include "scene.h"
#include "fade.h"
#include "gba.h"

static int current_scene = -1;

void load_scene(int scene_id) {
    fade_out();
    current_scene = scene_id;

    switch (scene_id) {
        case 0:
            REG_DISPCNT = MODE_3 | BG2_ENABLE;
            m3_plot(10, 10, RGB5(31, 0, 0));
            break;
        case 1:
            REG_DISPCNT = MODE_3 | BG2_ENABLE;
            m3_plot(100, 80, RGB5(0, 31, 0));
            break;
    }
}

void update_scene() {
    u16 keys = ~REG_KEYINPUT;

    if (keys & KEY_A) {
        load_scene((current_scene + 1) % 2);
    }
}

void render_scene() {
    // Add scene-specific rendering here
}