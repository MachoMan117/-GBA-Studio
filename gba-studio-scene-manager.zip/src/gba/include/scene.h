#ifndef SCENE_H
#define SCENE_H

void load_scene(int scene_id);
void update_scene();
void render_scene();

#endif