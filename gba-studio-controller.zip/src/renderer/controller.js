export function setupGamepad(handler) {
  function pollGamepad() {
    const gamepad = navigator.getGamepads()[0];
    if (gamepad) {
      const state = {
        up: gamepad.buttons[12]?.pressed,
        down: gamepad.buttons[13]?.pressed,
        left: gamepad.buttons[14]?.pressed,
        right: gamepad.buttons[15]?.pressed,
        a: gamepad.buttons[1]?.pressed,
        b: gamepad.buttons[0]?.pressed,
        start: gamepad.buttons[9]?.pressed,
        select: gamepad.buttons[8]?.pressed,
        l: gamepad.buttons[4]?.pressed,
        r: gamepad.buttons[5]?.pressed
      };
      handler(state);
    }
    requestAnimationFrame(pollGamepad);
  }

  pollGamepad();
}