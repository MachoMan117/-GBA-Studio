#include "affine.h"
#include "gba.h"

void setup_affine_sprite() {
    OBJ_AFFINE *aff = &OBJ_AFFINE_MEM[0];

    aff->pa = 0x100;
    aff->pb = -0x100;
    aff->pc = 0x100;
    aff->pd = 0x100;

    OBJ_ATTR *sprite = &OAM[0];
    sprite->attr0 = ATTR0_SQUARE | ATTR0_REG | ATTR0_8BPP | ATTR0_Y(80);
    sprite->attr1 = ATTR1_SIZE_32 | ATTR1_AFF_ID(0) | ATTR1_X(120);
    sprite->attr2 = ATTR2_ID(0);
}