#include "fade.h"
#include "gba.h"

void fade_out() {
    REG_BLDCNT = BLEND_ALL | BLEND_BLACK;
    for (int i = 0; i <= 16; i++) {
        REG_BLDY = i;
        for (volatile int j = 0; j < 10000; j++);
    }
}