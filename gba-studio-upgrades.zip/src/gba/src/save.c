#include "save.h"
#define SAVE_ADDRESS ((volatile u8*) 0x0E000000)

void save_data(u8 data) {
    SAVE_ADDRESS[0] = data;
}

u8 load_data() {
    return SAVE_ADDRESS[0];
}