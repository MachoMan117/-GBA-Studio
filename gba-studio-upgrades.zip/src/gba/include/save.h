#ifndef SAVE_H
#define SAVE_H

#include "gba_types.h"

void save_data(u8 data);
u8 load_data();

#endif