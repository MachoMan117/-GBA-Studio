#ifndef AFFINE_H
#define AFFINE_H

void setup_affine_sprite();

#endif