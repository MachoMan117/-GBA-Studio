#ifndef FADE_H
#define FADE_H

void fade_out();

#endif