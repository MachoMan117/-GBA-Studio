# 🎮 GBA Studio (Work in Progress)

A modern, drag-and-drop game creator for the **Game Boy Advance**, inspired by GB Studio — but built for 32-bit GBA development, complete with scene editors, native asset processing, and real GBA hardware builds.

---

## 🚀 About the Project

**GBA Studio** is a work-in-progress tool that lets you create Game Boy Advance games **without writing code**. It features:

- 🎨 Pixel-perfect **scene editor** (240x160 canvas)
- 🖼 Drag-and-drop **image + audio import** (auto-processed to GBA format)
- 🎵 Flexible music import (MP3, WAV, etc.)
- ⚙️ Native **GBA C engine** compiled with `arm-none-eabi-gcc`
- 🧱 Project manager (assets, scenes, project.json)
- 💻 Cross-platform: Works on Windows, macOS, and Linux
- 📦 Build & export `.gba` ROMs ready to run on emulators or flashcarts

All of it wrapped in a sleek **Electron app** using **Vue 3** for UI and `ffi-napi` to link to native C code.

---

## 🛠 Current Features

| Feature | Status |
|--------|--------|
| Scene editor (canvas) | ✅ Working |
| GBA C engine | ✅ Compiles and runs |
| Asset importer (images/audio) | ✅ Supports image/audio via ffmpeg & jimp |
| Project creation/loading | ✅ JSON-based |
| GBA ROM exporting | ✅ via `make` and `objcopy` |
| Multi-platform builds | ✅ Electron Builder setup |

---

## 🧰 How to Use

### 🔧 Requirements

- Node.js
- `make`
- `ffmpeg`
- `arm-none-eabi-gcc` (GBA toolchain)
- `electron` (installed via npm)

### 📦 Install

```bash
git clone https://github.com/yourusername/gba-studio
cd gba-studio
make install
```

### ▶️ Run the App

```bash
make run
```

### 🧱 Build GBA ROM

```bash
make build
```

### 📦 Package Electron App

```bash
make package
```

---

## 👀 Screenshots

*Coming soon.* Want to see the interface? Ask and I’ll share early previews!

---

## 🤝 Contributing

I'm currently developing this solo, but I’d **love help** from anyone interested in:

- GBA engine programming (C)
- Vue 3 / Electron frontend
- Audio format conversion
- Level editors or tile-based systems
- UI design, polish, or icons

Feel free to open issues or contact me directly.

---

## 📫 Contact

- Reddit: `u/yourusername`
- Discord: `@yourdiscordname`
- GitHub: Open an Issue or PR

---

## ⚠️ Disclaimer

This project is in **early alpha**. Features are still being developed and the engine is subject to change. This is not affiliated with the original GB Studio project — it’s an independent spiritual successor aimed at the GBA platform.

---

## 📄 License

MIT License